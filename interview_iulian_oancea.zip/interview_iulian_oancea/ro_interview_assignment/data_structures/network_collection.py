import ipaddress
from .entry import Entry

class NetworkCollection:
    def __init__(self, ipv4_network, raw_entry_list):
        """
        Constructor for NetworkCollection data structure.

        self.ipv4_network -> ipaddress.IPv4Network
        self.entries -> list(Entry)
        """
        entries = []
        for dictionary in raw_entry_list:
            entries.append(Entry(dictionary['address'], dictionary['available'], dictionary['last_used']))
        self.entries = entries
        self.ipv4_network = ipaddress.ip_network(ipv4_network)
        pass

    def remove_invalid_records(self):
        """
        Removes invalid objects from the entries list.
        """
        aux = []
        for entry in self.entries:
            try:
                if ipaddress.ip_address(entry.address) in list(self.ipv4_network.hosts()):
                    aux.append(entry)
            except:
                pass
        self.entries = aux
        pass

    def sort_records(self):
        """
        Sorts the list of associated entries in ascending order.
        DO NOT change this method, make the changes in entry.py :)
        """
        self.entries = sorted(self.entries)
